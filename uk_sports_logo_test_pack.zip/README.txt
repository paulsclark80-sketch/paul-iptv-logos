UK SPORTS LOGO TEST PACK

Master geometry:
- 512 x 90 px transparent canvas
- Visible artwork height: 59 px
- Artwork centred horizontally and vertically
- Original source branding and colours preserved
- No AI-redrawn logos in these test files

Test channels:
- Sky Sports Main Event
- Sky Sports Premier League
- Sky Sports Football
- Sky Sports F1

TNT Sports 1 will be added once its exact source artwork is confirmed.
